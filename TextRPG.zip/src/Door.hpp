#pragma once
#include <string>
#include "fogpi/Math.hpp"

struct Door
{
    Vector2D pos;
    std::string path;
};